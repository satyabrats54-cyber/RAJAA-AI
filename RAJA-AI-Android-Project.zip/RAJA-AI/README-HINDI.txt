RAJA AI - शुरुआती Android प्रोजेक्ट

इस ZIP में RAJA AI का शुरुआती Kotlin Android app source है।
यह demo app है: इसमें basic chat replies, Android speech-to-text और Hindi text-to-speech हैं।
यह अभी ChatGPT-जैसा online AI नहीं है; उसके लिए अलग AI service और सुरक्षित configuration जोड़नी होगी।

APK बनाने का आसान रास्ता:
1. इस ZIP को GitHub repository में upload करें।
2. GitHub में Actions tab खोलें।
3. 'Build RAJA AI APK' workflow चुनें और Run workflow दबाएँ।
4. Build पूरा होने पर Artifacts में RAJA-AI-debug-apk डाउनलोड करें।
5. ZIP खोलकर app-debug.apk फोन में install करें।

नोट: इस प्रोजेक्ट में Gradle wrapper शामिल नहीं है। GitHub Actions में installed Gradle से build होता है।

package com.raja.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private var ttsReady = false
    private val cyan = Color.rgb(53, 201, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(Color.rgb(5, 11, 24))
        }

        val title = TextView(this).apply {
            text = "RAJA AI"
            textSize = 30f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"
            textSize = 11f
            letterSpacing = 0.18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 18)
        }
        page.addView(subtitle)

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 64f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(12, 31, 55), 180, cyan)
            setPadding(28, 12, 28, 12)
        }
        val orbWrap = FrameLayout(this).apply {
            addView(orb, FrameLayout.LayoutParams(150, 150, Gravity.CENTER))
        }
        page.addView(orbWrap, LinearLayout.LayoutParams(-1, 170))

        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(10, 20, 37), 18, Color.rgb(28, 58, 82))
        }
        addMessage("RAJA AI", "नमस्ते! मैं RAJA AI हूँ। मुझसे हिंदी या English में बात करें।")
        val scroll = ScrollView(this)
        scroll.addView(chat)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "यहाँ अपना संदेश लिखें..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            background = rounded(Color.rgb(17, 30, 49), 14, Color.rgb(45, 88, 120))
            setPadding(14, 12, 14, 12)
        }
        page.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply {
            text = "SEND"
            setTextColor(Color.BLACK)
            background = rounded(cyan, 14, cyan)
            setOnClickListener { handle(input.text.toString()) }
        }
        val mic = Button(this).apply {
            text = "🎙 VOICE"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(18, 48, 75), 14, cyan)
            setOnClickListener { startListening() }
        }
        buttons.addView(send, LinearLayout.LayoutParams(0, 54, 1f).apply { rightMargin = 8 })
        buttons.addView(mic, LinearLayout.LayoutParams(0, 54, 1f))
        page.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })

        setContentView(page)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(2, stroke)
        }

    private fun addMessage(who: String, msg: String) {
        val tv = TextView(this).apply {
            text = "$who\n$msg"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 12)
        }
        chat.addView(tv)
    }

    private fun handle(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        addMessage("YOU", text)
        input.setText("")
        val answer = when {
            text.contains("hello", true) || text.contains("नमस्ते") || text.contains("हेलो") ->
                "नमस्ते! मैं आपकी मदद के लिए तैयार हूँ।"
            text.contains("तुम कौन", true) || text.contains("who are you", true) ->
                "मैं RAJA AI हूँ, आपका personal voice assistant."
            text.contains("समय", true) || text.contains("time", true) ->
                "अभी समय है " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            text.contains("नाम", true) || text.contains("your name", true) ->
                "मेरा नाम RAJA AI है।"
            else ->
                "मैं अभी basic demo mode में हूँ। असली ChatGPT-जैसे जवाबों के लिए बाद में AI service जोड़नी होगी।"
        }
        addMessage("RAJA AI", answer)
        if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "raja_reply")
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "RAJA AI से बात करें")
        }
        try {
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            addMessage("RAJA AI", "इस फोन में voice recognition उपलब्ध नहीं है।")
        }
    }

    @Deprecated("Deprecated by Android but works on supported devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handle(spoken)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
